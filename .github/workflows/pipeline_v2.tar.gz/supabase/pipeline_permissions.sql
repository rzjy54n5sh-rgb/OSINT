-- ============================================================
-- PIPELINE PERMISSIONS PATCH
-- Run this in Supabase SQL Editor to allow GitHub Actions
-- scripts (using service_role key) to INSERT data.
-- ============================================================

-- articles: allow insert from service role
create policy "Service role insert articles"
  on public.articles for insert
  to service_role
  with check (true);

-- articles: allow update from service role  
create policy "Service role update articles"
  on public.articles for update
  to service_role
  using (true);

-- market_data: allow insert from service role
create policy "Service role insert market_data"
  on public.market_data for insert
  to service_role
  with check (true);

-- social_trends: allow insert from service role
create policy "Service role insert social_trends"
  on public.social_trends for insert
  to service_role
  with check (true);

-- disinfo_claims: allow insert from service role
create policy "Service role insert disinfo_claims"
  on public.disinfo_claims for insert
  to service_role
  with check (true);

-- nai_scores: allow insert + update from service role
create policy "Service role insert nai_scores"
  on public.nai_scores for insert
  to service_role
  with check (true);

create policy "Service role update nai_scores"
  on public.nai_scores for update
  to service_role
  using (true);

-- country_reports: allow insert + update from service role
create policy "Service role insert country_reports"
  on public.country_reports for insert
  to service_role
  with check (true);

create policy "Service role update country_reports"
  on public.country_reports for update
  to service_role
  using (true);

-- scenario_probabilities: allow insert + update from service role
create policy "Service role insert scenario_probabilities"
  on public.scenario_probabilities for insert
  to service_role
  with check (true);

create policy "Service role update scenario_probabilities"
  on public.scenario_probabilities for update
  to service_role
  using (true);
